import React from 'react';
import { Navigate, useLocation } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';

export function RequireAuth({ children }: {children: React.ReactNode;}) {
  const { user } = useAuth();
  const location = useLocation();
  if (!user)
  return (
    <Navigate
      to="/login"
      replace
      state={{ from: location.pathname + location.search }} />);


  return <>{children}</>;
}

export function RequireAdmin({ children }: {children: React.ReactNode;}) {
  const { user, isAdmin } = useAuth();
  const location = useLocation();
  if (!user)
  return (
    <Navigate
      to="/login"
      replace
      state={{ from: location.pathname + location.search }} />);


  if (!isAdmin) return <Navigate to="/portal/library" replace />;
  return <>{children}</>;
}