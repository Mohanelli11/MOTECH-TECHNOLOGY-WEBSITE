export const manifest = {
  screens: {
    scr_jhyw81: { name: "Home / Hero", route: "/#home", position: { "x": 160, "y": 220 } },
    scr_ltrl17: { name: "About", route: "/#about", position: { "x": 1560, "y": 220 } },
    scr_s7udk4: { name: "Products", route: "/#products", position: { "x": 160, "y": 2200 } },
    scr_l9yvl7: { name: "Why Choose MOTECH", route: "/#solutions", position: { "x": 2960, "y": 220 } },
    scr_3yv97e: { name: "Industries Served", route: "/#industries", position: { "x": 1560, "y": 2200 } },
    scr_zzy9ur: { name: "Energy Dashboard", route: "/#energy-dashboard", position: { "x": 160, "y": 4180 } },
    scr_nguook: { name: "Contact", route: "/#contact", position: { "x": 160, "y": 6160 } },
    scr_r1t86m: { name: "Store — Catalogue", route: "/store", position: { "x": 160, "y": 8140 } },
    scr_z6pwd3: { name: "Product Detail", route: "/store/smart-energy-meter-sem-100", position: { "x": 1560, "y": 8140 } },
    scr_sjdqb4: { name: "Sign In", route: "/login", position: { "x": 160, "y": 10120 } },
    scr_w841h0: { name: "Create Account", route: "/register", position: { "x": 1560, "y": 10120 } },
    scr_3t1y5q: { name: "Reset Password", route: "/reset-password", position: { "x": 2960, "y": 10120 } },
    scr_77gfuo: { name: "Checkout & Bank Payment", route: "/checkout/smart-energy-meter-sem-100", position: { "x": 2960, "y": 8140 } },
    scr_iqih1a: { name: "Portal — My Library", route: "/portal/library", position: { "x": 1560, "y": 12100 } },
    scr_3bt43k: { name: "Portal — Orders & Payments", route: "/portal/orders", position: { "x": 2960, "y": 12100 } },
    scr_8jao4g: { name: "Portal — Licences", route: "/portal/licenses", position: { "x": 4360, "y": 12100 } },
    scr_t6b8eq: { name: "Portal — Profile", route: "/portal/profile", position: { "x": 160, "y": 12100 } },
    scr_nmow24: { name: "Admin — Overview", route: "/admin", position: { "x": 160, "y": 14080 } },
    scr_xm5wkw: { name: "Admin — Payment Verification", route: "/admin/orders", position: { "x": 4360, "y": 14080 } },
    scr_asc6rw: { name: "Admin — Products", route: "/admin/products", position: { "x": 1560, "y": 14080 } },
    scr_8yvubh: { name: "Admin — Documentation Manager", route: "/admin/documentation", position: { "x": 5760, "y": 14080 } },
    scr_vytig4: { name: "Admin — Customers", route: "/admin/customers", position: { "x": 2960, "y": 14080 } }
  },
  sections: {
    sec_mnl9jq: { name: "Hero & Company", x: 0, y: 0, width: 4320, height: 1180 },
    sec_xut83g: { name: "Products & Markets", x: 0, y: 1980, width: 2920, height: 1180 },
    sec_9eqf2l: { name: "Feature Showcase", x: 0, y: 3960, width: 1520, height: 1180 },
    sec_woncfa: { name: "Engagement", x: 0, y: 5940, width: 1520, height: 1180 },
    sec_ikiqek: { name: "Store & Checkout", x: 0, y: 7920, width: 4320, height: 1180 },
    sec_vakthf: { name: "Authentication", x: 0, y: 9900, width: 4320, height: 1180 },
    sec_8m51mq: { name: "User Portal", x: 0, y: 11880, width: 5720, height: 1180 },
    sec_kq57zc: { name: "Admin Dashboard", x: 0, y: 13860, width: 7120, height: 1180 }
  },
  layers: [
  { kind: "section", id: "sec_mnl9jq", children: [
    { kind: "screen", id: "scr_jhyw81" },
    { kind: "screen", id: "scr_ltrl17" },
    { kind: "screen", id: "scr_l9yvl7" }]
  },
  { kind: "section", id: "sec_xut83g", children: [
    { kind: "screen", id: "scr_s7udk4" },
    { kind: "screen", id: "scr_3yv97e" }]
  },
  { kind: "section", id: "sec_9eqf2l", children: [
    { kind: "screen", id: "scr_zzy9ur" }]
  },
  { kind: "section", id: "sec_woncfa", children: [
    { kind: "screen", id: "scr_nguook" }]
  },
  { kind: "section", id: "sec_ikiqek", children: [
    { kind: "screen", id: "scr_r1t86m" },
    { kind: "screen", id: "scr_z6pwd3" },
    { kind: "screen", id: "scr_77gfuo" }]
  },
  { kind: "section", id: "sec_vakthf", children: [
    { kind: "screen", id: "scr_sjdqb4" },
    { kind: "screen", id: "scr_w841h0" },
    { kind: "screen", id: "scr_3t1y5q" }]
  },
  { kind: "section", id: "sec_8m51mq", children: [
    { kind: "screen", id: "scr_t6b8eq" },
    { kind: "screen", id: "scr_iqih1a" },
    { kind: "screen", id: "scr_3bt43k" },
    { kind: "screen", id: "scr_8jao4g" }]
  },
  { kind: "section", id: "sec_kq57zc", children: [
    { kind: "screen", id: "scr_nmow24" },
    { kind: "screen", id: "scr_asc6rw" },
    { kind: "screen", id: "scr_vytig4" },
    { kind: "screen", id: "scr_xm5wkw" },
    { kind: "screen", id: "scr_8yvubh" }]
  }]

};